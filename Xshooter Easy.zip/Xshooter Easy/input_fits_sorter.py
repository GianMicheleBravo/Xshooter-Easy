# THIS SCRIPT IS MEANT TO TAKE ALL THE INPUT FITS FILES AND PUT THEM IN APPROPRIATE FOLDERS

import astropy.table
import astropy
import os

in_folder_name = 'Input'

file_names = list(os.walk(f'./{in_folder_name}'))
file_names = file_names[0]
file_names = file_names[2]

for file_name in file_names:
    if '.fits' in file_name:
        in_path = f'./{in_folder_name}/{file_name}'

        try:
            dat = astropy.io.fits.open(in_path)

            header = dat[0].header
            arm = header['HIERARCH ESO SEQ ARM']

            if arm == 'UVB' or arm == 'VIS' or arm == 'NIR':
                str(header)  # NOTE: somehow, the code doesn't work without this

                out_path = f'./{arm}/{file_name}'
                dat.writeto(out_path, overwrite=True)

        except:
            print(f'WARNING: file {file_name} could not be read or written properly.')

print('Done!')
