# THIS SCRIPT IS MEANT TO MAKE A WAVELENGTH-FLUX PLOT FOR A SLICE OF THE SLIT. THE SLICE IS CHOSEN BY YOU


# IMPORTS

import numpy as np
import matplotlib.pyplot as plt
import astropy
import astropy.table

def sum_slice(table, start_fraction, end_fraction):
    N_rows = table.shape[0]

    start_index = round((N_rows-1) * start_fraction)
    end_index = round((N_rows-1) * end_fraction)

    out = table[start_index: end_index]
    return np.sum(out, axis=0)

#TODO: set this
start_fraction = 0.4  # The start fraction of the slit to use
end_fraction = 0.6  # The end fraction of the slit to use


# CODE

arms = ('NIR', 'VIS', 'UVB')

for arm in arms:
    path_SDP = f'./Output/SDP_SCI_SLIT_MERGE1D_{arm}.fits'
    path_2D = f'./Output/SCI_SLIT_MERGE2D_{arm}.fits'

    try:
        dat = astropy.io.fits.open(path_SDP)
        dat = dat[1].data
        wavelength = dat['WAVE'][0]

        dat = astropy.io.fits.open(path_2D)
        dat = dat[0].data


        flux = sum_slice(dat, start_fraction, end_fraction)

        plt.plot(wavelength, flux, label=f'{arm} 2D spectra, slit slice from {start_fraction} to {end_fraction}')

    except:
        pass

plt.xlabel('Wavelength (nm)')
plt.ylabel('Flux (adu)')
plt.grid()
plt.legend()
plt.show()
