# THIS SCRIPT IS MEANT TO MAKE A .sof FILE THAT WORKS FOR THE xsh_orderpos RECIPE


# IMPORTS

import astropy.table
import astropy
import os
import xsh_conditions_UVB


# TODO: set all of this

sof_name = 'xsh_orderpos.sof'

tag_1 = f'ORDERDEF_D2_UVB'
tag_1_number = 1
condition_1 = xsh_conditions_UVB.ORDERDEF_D2_UVB

tag_2 = f'MASTER_BIAS_UVB'
tag_2_number = 1
condition_2 = xsh_conditions_UVB.MASTER_BIAS_UVB

tag_3 = f'SPECTRAL_FORMAT_TAB_UVB'
tag_3_number = 1
condition_3 = xsh_conditions_UVB.SPECTRAL_FORMAT_TAB_UVB

tag_4 = f'ORDER_TAB_GUESS_UVB'
tag_4_number = 1
condition_4 = xsh_conditions_UVB.ORDER_TAB_GUESS_UVB

tag_5 = f'BP_MAP_RP_UVB'
tag_5_number = 1
condition_5 = xsh_conditions_UVB.BP_MAP_RP_UVB


tags = (tag_1, tag_2, tag_3, tag_4, tag_5)
tag_numbers = [tag_1_number, tag_2_number, tag_3_number, tag_4_number,
               tag_5_number]
conditions = (condition_1, condition_2, condition_3, condition_4,
              condition_5)

number_of_tags = len(tags)

# GOING THROUGH THE FILES AND WRITING DOWN THOSE WE LIKE UNTIL WE HAVE ENOUGH
sof_file = open(sof_name, 'w')

file_names = os.listdir()
file_names = sorted(file_names)

for file_name in file_names:
    if '.fits' in file_name:
        dat = astropy.io.fits.open(file_name)

        header = dat[0].header
        file_already_used = False

        for i in range(number_of_tags):
            tag = tags[i]
            tag_number = tag_numbers[i]
            condition = conditions[i]

            if not file_already_used:
                if tag_number:
                    if condition(header, file_name):
                        text = f'{file_name}\t{tag}\n'
                        sof_file.write(text)

                        tag_numbers[i] -= 1
                        file_already_used = True

    if not any(tag_numbers):
        print('I have found all the files that the recipe needs!')
        break

if any(tag_numbers):
    for i in range(number_of_tags):
        tag = tags[i]
        tag_number = tag_numbers[i]

        if tag_number != 0:
            print(f'I still need {tag_number} files of tag {tag}')

sof_file.close()
print('Done!')
