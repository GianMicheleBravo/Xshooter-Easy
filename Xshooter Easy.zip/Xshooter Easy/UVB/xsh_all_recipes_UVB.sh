#!bin/bash

python3 xsh_mbias_UVB.py
echo 'BASH UVB SCRIPT: the xsh_mbias_UVB.py file just finished.'
esorex xsh_mbias xsh_mbias.sof
echo 'BASH UVB SCRIPT: the xsh_mbias recipe just finished.'

python3 xsh_predict_UVB.py
echo 'BASH UVB SCRIPT: the xsh_predict_UVB.py file just finished.'
esorex xsh_predict xsh_predict.sof
echo 'BASH UVB SCRIPT: the xsh_predict recipe just finished.'

python3 xsh_orderpos_UVB.py
echo 'BASH UVB SCRIPT: the xsh_orderpos_UVB.py file just finished.'
esorex xsh_orderpos xsh_orderpos.sof
echo 'BASH UVB SCRIPT: the xsh_orderpos recipe just finished.'

python3 xsh_mflat_UVB.py
echo 'BASH UVB SCRIPT: the xsh_mflat_UVB.py file just finished.'
esorex xsh_mflat xsh_mflat.sof
echo 'BASH UVB SCRIPT: the xsh_mflat recipe just finished.'

python3 xsh_2dmap_UVB.py
echo 'BASH UVB SCRIPT: the xsh_2dmap_UVB.py file just finished.'
esorex xsh_2dmap xsh_2dmap.sof
echo 'BASH UVB SCRIPT: the xsh_2dmap recipe just finished.'

python3 xsh_scired_slit_stare_UVB.py
echo 'BASH UVB SCRIPT: the xsh_scired_slit_stare_UVB.py file just finished.'
esorex xsh_scired_slit_stare --generate-SDP-format=true  xsh_scired_slit_stare.sof
echo 'BASH UVB SCRIPT: the xsh_scired_slit_stare recipe just finished.'

echo 'BASH UVB SCRIPT: done!'
