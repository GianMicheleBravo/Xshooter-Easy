# THIS SCRIPT IS MEANT TO CONTAIN CONDITIONS THAT CHECK WHETER A .fits FILE HAS A SPECIFIC TAG OR NOT

import astropy.io.fits


def WAVE_UVB(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the WAVE_UVB tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' not in header:
        if 'ORIGFILE' in header:
            if f'SLT_WAVE_UVB' in header['ORIGFILE']:
                if 'T / Lamp activated.' in str(header):
                    return True

    return False


def SPECTRAL_FORMAT_TAB_UVB(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the SPECTRAL_FORMAT_TAB_UVB tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'SPECTRAL_FORMAT_TAB_UVB' == header['HIERARCH ESO PRO CATG']:
            return True

    return False


def ARC_LINE_LIST_UVB(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the ARC_LINE_LIST_UVB tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'ARC_LINE_LIST_UVB' == header['HIERARCH ESO PRO CATG']:
            return True

    return False


def XSH_MOD_CFG_OPT_FMT_UVB(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the XSH_MOD_CFG_OPT_FMT_UVB tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'XSH_MOD_CFG_OPT_FMT_UVB' == header['HIERARCH ESO PRO CATG']:
            return True
    return False


def BP_MAP_RP_UVB(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the BP_MAP_RP_UVB tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'BP_MAP_RP_UVB' == header['HIERARCH ESO PRO CATG']:
            return True
    return False


def ORDER_TAB_EDGES_SLIT_UVB(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the ORDER_TAB_EDGES_SLIT_UVB tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'ORDER_TAB_EDGES_SLIT_UVB' == header['HIERARCH ESO PRO CATG']:
            return True
    return False


def DARK_UVB(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the DARK_UVB tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' not in header:
        if 'ORIGFILE' in header:
            if 'DARK_UVB' in header['ORIGFILE']:
                return True

    return False


def BIAS_UVB(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the BIAS_UVB tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' not in header:
        if 'ORIGFILE' in header:
            if 'BIAS_UVB' in header['ORIGFILE']:
                return True

    return False


def FLAT_SLIT_UVB(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the FLAT_SLIT_UVB tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' not in header:
        if 'ORIGFILE' in header:
            if f'SLT_FLAT_UVB' in header['ORIGFILE']:
                if 'T / Lamp activated.' in str(header):
                    return True

    return False


def ORDER_TAB_CENTR_UVB(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the ORDER_TAB_CENTR_UVB tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'ORDER_TAB_CENTR_UVB' == header['HIERARCH ESO PRO CATG']:
            return True

    return False


def ORDERDEF_UVB(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the ORDERDEF_UVB tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' not in header:
        if 'ORIGFILE' in header:
            if f'SLT_ODEF_UVB' in header['ORIGFILE']:
                if 'T / Lamp activated.' in str(header):
                    return True

        return False


def ORDER_TAB_GUESS_UVB(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the ORDER_TAB_GUESS_UVB tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'ORDER_TAB_GUESS_UVB' == header['HIERARCH ESO PRO CATG']:
            return True

    return False


def FMTCHK_UVB(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the FMTCHK_UVB tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'ORIGFILE' in header:
        if 'SLT_FCK_UVB' in header['ORIGFILE']:
            if 'T / Lamp activated.' in str(header):
                return True

    return False


def XSH_MOD_CFG_TAB_UVB(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the XSH_MOD_CFG_TAB_UVB tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'XSH_MOD_CFG_TAB_UVB' == header['HIERARCH ESO PRO CATG']:
            return True
    return False


def XSH_MOD_CFG_OPT_2D_UVB(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the XSH_MOD_CFG_OPT_2D_UVB tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'XSH_MOD_CFG_OPT_2D_UVB' == header['HIERARCH ESO PRO CATG']:
            return True
    return False


def STD_FLUX_SLIT_STARE_UVB(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the STD_FLUX_SLIT_STARE_UVB tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' not in header:
        if 'ORIGFILE' in header:
            if 'SLT_OBJ_UVB' in header['ORIGFILE']:
                if 'HIERARCH ESO DPR CATG' in header:
                    if 'CALIB' in header['HIERARCH ESO DPR CATG']:
                        return True

    return False


def MASTER_DARK_UVB(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the MASTER_DARK_UVB tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'MASTER_DARK_UVB' == header['HIERARCH ESO PRO CATG']:
            return True

    return False


def MASTER_BIAS_UVB(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the MASTER_BIAS_UVB tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''
    if 'HIERARCH ESO PRO CATG' in header:
        if 'MASTER_BIAS_UVB' == header['HIERARCH ESO PRO CATG']:
            return True

    return False


def MASTER_FLAT_SLIT_UVB(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the MASTER_FLAT_SLIT_UVB tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'MASTER_FLAT_SLIT_UVB' == header['HIERARCH ESO PRO CATG']:
            return True

    return False


def DISP_TAB_UVB(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the DISP_TAB_UVB tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'DISP_TAB_UVB' == header['HIERARCH ESO PRO CATG']:
            return True

    return False


def FLUX_STD_CATALOG_UVB(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the FLUX_STD_CATALOG_UVB tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'FLUX_STD_CATALOG_UVB' == header['HIERARCH ESO PRO CATG']:
            return True

    return False


def RESP_FIT_POINTS_CAT_UVB(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the RESP_FIT_POINTS_CAT_UVB tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'RESP_FIT_POINTS_CAT_UVB' == header['HIERARCH ESO PRO CATG']:
            return True

    return False


def ATMOS_EXT_UVB(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the ATMOS_EXT_UVB tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'ATMOS_EXT_UVB' == header['HIERARCH ESO PRO CATG']:
            return True

    return False


def SKY_LINE_LIST_UVB(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the SKY_LINE_LIST_UVB tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'SKY_LINE_LIST_UVB' == header['HIERARCH ESO PRO CATG']:
            return True

    return False


def OBJECT_SLIT_STARE_UVB(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the OBJECT_SLIT_STARE_UVB tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' not in header:
        if 'ORIGFILE' in header:
            if 'SLT_OBJ_UVB' in header['ORIGFILE']:
                if 'HIERARCH ESO DPR CATG' in header:
                    if 'SCIENCE' in header['HIERARCH ESO DPR CATG']:
                        return True

    return False


def ORDERDEF_D2_UVB(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the ORDERDEF_D2_UVB tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' not in header:
        if 'ORIGFILE' in header:
            if f'SLT_ODEF_UVB' in header['ORIGFILE']:
                if 'HIERARCH ESO INS LAMP3 NAME' in header:
                    if 'UVB_Low_D2' in header['HIERARCH ESO INS LAMP3 NAME']:
                        if 'T / Lamp activated.' in str(header):
                            return True
    return False


def FLAT_D2_SLIT_UVB(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the FLAT_D2_SLIT_UVB tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' not in header:
        if 'ORIGFILE' in header:
            if f'SLT_FLAT_UVB' in header['ORIGFILE']:
                if 'HIERARCH ESO INS LAMP3 NAME' in header:
                    if 'UVB_Low_D2' in header['HIERARCH ESO INS LAMP3 NAME']:
                        if 'T / Lamp activated.' in str(header):
                            return True

    return False


def FLAT_QTH_SLIT_UVB(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the FLAT_QTH_SLIT_UVB tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' not in header:
        if 'ORIGFILE' in header:
            if f'SLT_FLAT_UVB' in header['ORIGFILE']:
                if 'HIERARCH ESO INS LAMP4 NAME' in header:
                    if 'UVB_High' in header['HIERARCH ESO INS LAMP4 NAME']:
                        if 'T / Lamp activated.' in str(header):
                            return True
    return False


def GENERIC_TAG(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the GENERIC_TAG tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if False:
        return True

    return False
