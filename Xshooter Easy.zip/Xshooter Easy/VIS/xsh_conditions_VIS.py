# THIS SCRIPT IS MEANT TO CONTAIN CONDITIONS THAT CHECK WHETER A .fits FILE HAS A SPECIFIC TAG OR NOT

import astropy.io.fits


def WAVE_VIS(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the WAVE_VIS tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' not in header:
        if 'ORIGFILE' in header:
            if f'SLT_WAVE_VIS' in header['ORIGFILE']:
                if 'T / Lamp activated.' in str(header):
                    return True

    return False


def SPECTRAL_FORMAT_TAB_VIS(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the SPECTRAL_FORMAT_TAB_VIS tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'SPECTRAL_FORMAT_TAB_VIS' == header['HIERARCH ESO PRO CATG']:
            return True

    return False


def ARC_LINE_LIST_VIS(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the ARC_LINE_LIST_VIS tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'ARC_LINE_LIST_VIS' == header['HIERARCH ESO PRO CATG']:
            return True

    return False


def XSH_MOD_CFG_OPT_FMT_VIS(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the XSH_MOD_CFG_OPT_FMT_VIS tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'XSH_MOD_CFG_OPT_FMT_VIS' == header['HIERARCH ESO PRO CATG']:
            return True
    return False


def BP_MAP_RP_VIS(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the BP_MAP_RP_VIS tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'BP_MAP_RP_VIS' == header['HIERARCH ESO PRO CATG']:
            return True
    return False


def ORDER_TAB_EDGES_SLIT_VIS(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the ORDER_TAB_EDGES_SLIT_VIS tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'ORDER_TAB_EDGES_SLIT_VIS' == header['HIERARCH ESO PRO CATG']:
            return True
    return False


def DARK_VIS(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the DARK_VIS tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' not in header:
        if 'ORIGFILE' in header:
            if 'DARK_VIS' in header['ORIGFILE']:
                return True

    return False


def BIAS_VIS(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the BIAS_VIS tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' not in header:
        if 'ORIGFILE' in header:
            if 'BIAS_VIS' in header['ORIGFILE']:
                return True

    return False


def FLAT_SLIT_VIS(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the FLAT_SLIT_VIS tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' not in header:
        if 'ORIGFILE' in header:
            if f'SLT_FLAT_VIS' in header['ORIGFILE']:
                if 'T / Lamp activated.' in str(header):
                    return True

    return False


def ORDER_TAB_CENTR_VIS(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the ORDER_TAB_CENTR_VIS tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'ORDER_TAB_CENTR_VIS' == header['HIERARCH ESO PRO CATG']:
            return True

    return False


def ORDERDEF_VIS(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the ORDERDEF_VIS tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' not in header:
        if 'ORIGFILE' in header:
            if f'SLT_ODEF_VIS' in header['ORIGFILE']:
                if 'T / Lamp activated.' in str(header):
                    return True

    return False


def ORDER_TAB_GUESS_VIS(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the ORDER_TAB_GUESS_VIS tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'ORDER_TAB_GUESS_VIS' == header['HIERARCH ESO PRO CATG']:
            return True

    return False


def FMTCHK_VIS(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the FMTCHK_VIS tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''
    if 'HIERARCH ESO PRO CATG' not in header:
        if 'ORIGFILE' in header:
            if 'SLT_FCK_VIS' in header['ORIGFILE']:
                if 'T / Lamp activated.' in str(header):
                    return True

    return False


def XSH_MOD_CFG_TAB_VIS(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the XSH_MOD_CFG_TAB_VIS tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'XSH_MOD_CFG_TAB_VIS' == header['HIERARCH ESO PRO CATG']:
            return True
    return False


def XSH_MOD_CFG_OPT_2D_VIS(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the XSH_MOD_CFG_OPT_2D_VIS tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'XSH_MOD_CFG_OPT_2D_VIS' == header['HIERARCH ESO PRO CATG']:
            return True
    return False


def ARC_SLIT_VIS_ON(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the ARC_SLIT_VIS_ON tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' not in header:
        if 'ORIGFILE' in header:
            if 'SLT_ARC_VIS' in header['ORIGFILE']:
                if 'T / Lamp activated.' in str(header):
                    return True

    return False


def STD_FLUX_SLIT_STARE_VIS(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the STD_FLUX_SLIT_STARE_VIS tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' not in header:
        if 'ORIGFILE' in header:
            if 'SLT_OBJ_VIS' in header['ORIGFILE']:
                if 'HIERARCH ESO DPR CATG' in header:
                    if 'CALIB' in header['HIERARCH ESO DPR CATG']:
                        return True

    return False


def MASTER_DARK_VIS(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the MASTER_DARK_VIS tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'MASTER_DARK_VIS' == header['HIERARCH ESO PRO CATG']:
            return True

    return False


def MASTER_BIAS_VIS(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the MASTER_BIAS_VIS tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''
    if 'HIERARCH ESO PRO CATG' in header:
        if 'MASTER_BIAS_VIS' == header['HIERARCH ESO PRO CATG']:
            return True

    return False


def MASTER_FLAT_SLIT_VIS(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the MASTER_FLAT_SLIT_VIS tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'MASTER_FLAT_SLIT_VIS' == header['HIERARCH ESO PRO CATG']:
            return True

    return False


def DISP_TAB_VIS(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the DISP_TAB_VIS tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'DISP_TAB_VIS' == header['HIERARCH ESO PRO CATG']:
            return True

    return False


def FLUX_STD_CATALOG_VIS(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the FLUX_STD_CATALOG_VIS tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'FLUX_STD_CATALOG_VIS' == header['HIERARCH ESO PRO CATG']:
            return True

    return False


def RESP_FIT_POINTS_CAT_VIS(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the RESP_FIT_POINTS_CAT_VIS tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'RESP_FIT_POINTS_CAT_VIS' == header['HIERARCH ESO PRO CATG']:
            return True

    return False


def ATMOS_EXT_VIS(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the ATMOS_EXT_VIS tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'ATMOS_EXT_VIS' == header['HIERARCH ESO PRO CATG']:
            return True

    return False


def SKY_LINE_LIST_VIS(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the SKY_LINE_LIST_VIS tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'SKY_LINE_LIST_VIS' == header['HIERARCH ESO PRO CATG']:
            return True

    return False


def OBJECT_SLIT_STARE_VIS(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the OBJECT_SLIT_STARE_VIS tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' not in header:
        if 'ORIGFILE' in header:
            if 'SLT_OBJ_VIS' in header['ORIGFILE']:
                if 'HIERARCH ESO DPR CATG' in header:
                    if 'SCIENCE' in header['HIERARCH ESO DPR CATG']:
                        return True

    return False


def GENERIC_TAG(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the GENERIC_TAG tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if False:
        return True

    return False
