3# THIS SCRIPT IS MEANT TO MAKE A WAVELENGTH-FLUX PLOT FOR DIFFERNT DIVISIONS OF THE SLIT IN THE VIS ARM. THE DIVISIONS ARE CHOSEN BY YOU


# IMPORTS

import numpy as np
import matplotlib.pyplot as plt
import astropy
import astropy.table

# TODO: set this

divisions = 5  # The number of divisions along the slit
good_divisions = (2, 4)  # The indices of the divisions to plot
file_name_SDP = 'SDP_SCI_SLIT_MERGE1D_VIS.fits'
file_name_2D_star = 'SCI_SLIT_MERGE2D_VIS.fits'


# USEFUL FUNCTION

def positive_yaxis(xaxis, yaxis):
    '''
    Takes x and y arrays for a plot and reutrns the pairs of pointds where the y axis is not negaitve.

    Input:
        xaxis: array, shape M
        yaxis: array, shape M the one that you want to remove negative values from

    Output:
        (goox_xaxis, good_yaxis): x and y arrays ready to plot that won't have negative y values

    '''

    good = yaxis > 0
    goox_xaxis = xaxis[good]
    good_yaxis = yaxis[good]

    return goox_xaxis, good_yaxis

# CODE


dat = astropy.io.fits.open(file_name_SDP)
dat = dat[1].data
wavelength = dat['WAVE'][0]

dat = astropy.io.fits.open(file_name_2D_star)
dat = dat[0].data

N_slit_pixels = dat.shape[0]
for i in range(divisions):
    if i in good_divisions:
        min_row = round(i/divisions * N_slit_pixels)
        max_row = round((i + 1)/divisions * N_slit_pixels)

        dat_slice = dat[min_row: max_row]
        dat_slice = sum(np.array(dat_slice))

        good_wavelength, good_flux = positive_yaxis(wavelength, dat_slice)
        plt.plot(good_wavelength, good_flux,
                 label=f'Star 2D spectra, sum from slit pixel {min_row} to {max_row}')


plt.xlabel('Wavelength (nm)')
plt.ylabel('Flux (adu)')
plt.grid()
plt.legend()
plt.show()
