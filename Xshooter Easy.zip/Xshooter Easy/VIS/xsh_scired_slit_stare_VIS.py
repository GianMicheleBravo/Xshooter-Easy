# THIS SCRIPT IS MEANT TO MAKE A .sof FILE THAT WORKS FOR THE xsh_scired_slit_stare RECIPE


# IMPORTS

import astropy.table
import astropy
import os
import xsh_conditions_VIS

# TODO: set all of this

sof_name = 'xsh_scired_slit_stare.sof'

tag_1 = f'OBJECT_SLIT_STARE_VIS'
tag_1_number = 1
condition_1 = xsh_conditions_VIS.OBJECT_SLIT_STARE_VIS

tag_2 = f'SPECTRAL_FORMAT_TAB_VIS'
tag_2_number = 1
condition_2 = xsh_conditions_VIS.SPECTRAL_FORMAT_TAB_VIS

tag_3 = f'XSH_MOD_CFG_OPT_2D_VIS'
tag_3_number = 1
condition_3 = xsh_conditions_VIS.XSH_MOD_CFG_OPT_2D_VIS

tag_4 = f'MASTER_BIAS_VIS'
tag_4_number = 1
condition_4 = xsh_conditions_VIS.MASTER_BIAS_VIS

tag_5 = f'MASTER_FLAT_SLIT_VIS'
tag_5_number = 1
condition_5 = xsh_conditions_VIS.MASTER_FLAT_SLIT_VIS

tag_6 = f'ORDER_TAB_EDGES_SLIT_VIS'
tag_6_number = 1
condition_6 = xsh_conditions_VIS.ORDER_TAB_EDGES_SLIT_VIS

tag_7 = f'BP_MAP_RP_VIS'
tag_7_number = 1
condition_7 = xsh_conditions_VIS.BP_MAP_RP_VIS

tag_8 = 'SKY_LINE_LIST_VIS'
tag_8_number = 1
condition_8 = xsh_conditions_VIS.SKY_LINE_LIST_VIS

tag_9 = 'DISP_TAB_VIS'
tag_9_number = 1
condition_9 = xsh_conditions_VIS.DISP_TAB_VIS

tags = (tag_1, tag_2, tag_3, tag_4, tag_5, tag_6, tag_7, tag_8, tag_9)
tag_numbers = [tag_1_number, tag_2_number, tag_3_number, tag_4_number,
               tag_5_number, tag_6_number, tag_7_number, tag_8_number, tag_9_number]
conditions = (condition_1, condition_2, condition_3, condition_4,
              condition_5, condition_6, condition_7, condition_8, condition_9)

number_of_tags = len(tags)

# GOING THROUGH THE FILES AND WRITING DOWN THOSE WE LIKE UNTIL WE HAVE ENOUGH
sof_file = open(sof_name, 'w')

file_names = os.listdir()
file_names = sorted(file_names)

for file_name in file_names:
    if '.fits' in file_name:
        dat = astropy.io.fits.open(file_name)

        header = dat[0].header
        file_already_used = False

        for i in range(number_of_tags):
            tag = tags[i]
            tag_number = tag_numbers[i]
            condition = conditions[i]

            if not file_already_used:
                if tag_number:
                    if condition(header, file_name):
                        text = f'{file_name}\t{tag}\n'
                        sof_file.write(text)

                        tag_numbers[i] -= 1
                        file_already_used = True

    if not any(tag_numbers):
        print('I have found all the files that the recipe needs!')
        break

if any(tag_numbers):
    for i in range(number_of_tags):
        tag = tags[i]
        tag_number = tag_numbers[i]

        if tag_number != 0:
            print(f'I still need {tag_number} files of tag {tag}')

sof_file.close()
print('Done!')
