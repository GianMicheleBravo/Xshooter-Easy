# THIS SCRIPT IS MEANT TO MAKE A .sof FILE THAT WORKS FOR THE xsh_predict RECIPE


# IMPORTS

import astropy.table
import astropy
import os
import xsh_conditions_VIS


# TODO: set all of this

sof_name = 'xsh_predict.sof'

tag_1 = f'FMTCHK_VIS'
tag_1_number = 1
condition_1 = xsh_conditions_VIS.FMTCHK_VIS

tag_2 = f'MASTER_BIAS_VIS'
tag_2_number = 1
condition_2 = xsh_conditions_VIS.MASTER_BIAS_VIS

tag_3 = f'SPECTRAL_FORMAT_TAB_VIS'
tag_3_number = 1
condition_3 = xsh_conditions_VIS.SPECTRAL_FORMAT_TAB_VIS

tag_4 = f'ARC_LINE_LIST_VIS'
tag_4_number = 1
condition_4 = xsh_conditions_VIS.ARC_LINE_LIST_VIS

tag_5 = f'XSH_MOD_CFG_TAB_VIS'
tag_5_number = 1
condition_5 = xsh_conditions_VIS.XSH_MOD_CFG_TAB_VIS

tag_6 = f'BP_MAP_RP_VIS'
tag_6_number = 1
condition_6 = xsh_conditions_VIS.BP_MAP_RP_VIS


tags = (tag_1, tag_2, tag_3, tag_4, tag_5, tag_6)
tag_numbers = [tag_1_number, tag_2_number, tag_3_number, tag_4_number,
               tag_5_number, tag_6_number]
conditions = (condition_1, condition_2, condition_3, condition_4,
              condition_5, condition_6)

number_of_tags = len(tags)

# GOING THROUGH THE FILES AND WRITING DOWN THOSE WE LIKE UNTIL WE HAVE ENOUGH
sof_file = open(sof_name, 'w')

file_names = os.listdir()
file_names = sorted(file_names)

for file_name in file_names:
    if '.fits' in file_name:
        dat = astropy.io.fits.open(file_name)

        header = dat[0].header
        file_already_used = False

        for i in range(number_of_tags):
            tag = tags[i]
            tag_number = tag_numbers[i]
            condition = conditions[i]

            if not file_already_used:
                if tag_number:
                    if condition(header, file_name):
                        text = f'{file_name}\t{tag}\n'
                        sof_file.write(text)

                        tag_numbers[i] -= 1
                        file_already_used = True

    if not any(tag_numbers):
        print('I have found all the files that the recipe needs!')
        break

if any(tag_numbers):
    for i in range(number_of_tags):
        tag = tags[i]
        tag_number = tag_numbers[i]

        if tag_number != 0:
            print(f'I still need {tag_number} files of tag {tag}')

sof_file.close()
print('Done!')
