# THIS SCRIPT IS MEANT TO MAKE A WAVELENGTH-FLUX PLOT

# IMPORTS

import astropy.table
import astropy
import matplotlib.pyplot as plt

file_name = 'SDP_SCI_SLIT_MERGE1D_NIR.fits' # TODO: set this
dat = astropy.io.fits.open(file_name)
dat = dat[1].data

wavelength = dat['WAVE'][0]
flux = dat['FLUX'][0]

plt.plot(wavelength, flux, label = 'Science spectrum')
plt.xlabel('Wavelength (nm)')
plt.ylabel('Flux (adu)')
plt.grid()
plt.show()
