#!bin/bash

python3 xsh_mdark_NIR.py
echo 'BASH NIR SCRIPT: the xsh_mdark_NIR.py file just finished.'
esorex xsh_mdark xsh_mdark.sof
echo 'BASH NIR SCRIPT: the xsh_mdark recipe just finished.'

python3 xsh_predict_NIR.py
echo 'BASH NIR SCRIPT: the xsh_predict_NIR.py file just finished.'
esorex xsh_predict xsh_predict.sof
echo 'BASH NIR SCRIPT: the xsh_predict recipe just finished.'

python3 xsh_orderpos_NIR.py
echo 'BASH NIR SCRIPT: the xsh_orderpos_NIR.py file just finished.'
esorex xsh_orderpos xsh_orderpos.sof
echo 'BASH NIR SCRIPT: the xsh_orderpos recipe just finished.'

python3 xsh_mflat_NIR.py
echo 'BASH NIR SCRIPT: the xsh_mflat_NIR.py file just finished.'
esorex xsh_mflat xsh_mflat.sof
echo 'BASH NIR SCRIPT: the xsh_mflat recipe just finished.'

python3 xsh_2dmap_NIR.py
echo 'BASH NIR SCRIPT: the xsh_2dmap_NIR.py file just finished.'
esorex xsh_2dmap xsh_2dmap.sof
echo 'BASH NIR SCRIPT: the xsh_2dmap recipe just finished.'

python3 xsh_scired_slit_stare_NIR.py
echo 'BASH NIR SCRIPT: the xsh_scired_slit_stare_NIR.py file just finished.'
esorex xsh_scired_slit_stare --generate-SDP-format=true --removecrhsingle-niter=4 --removecrhsingle-flim=10.0 xsh_scired_slit_stare.sof
echo 'BASH NIR SCRIPT: the xsh_scired_slit_stare recipe just finished.'

echo 'BASH NIR SCRIPT: done!'
