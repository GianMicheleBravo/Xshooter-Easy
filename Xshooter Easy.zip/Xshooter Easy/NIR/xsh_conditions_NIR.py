# THIS SCRIPT IS MEANT TO CONTAIN CONDITIONS THAT CHECK WHETER A .fits FILE HAS A SPECIFIC TAG OR NOT

import astropy.io.fits


def WAVE_NIR_ON(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the WAVE_NIR_ON tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' not in header:
        if 'ORIGFILE' in header:
            if f'SLT_WAVE_NIR' in header['ORIGFILE']:
                if 'T / Lamp activated.' in str(header):
                    return True

    return False


def WAVE_NIR_OFF(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the WAVE_NIR_OFF tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' not in header:
        if 'ORIGFILE' in header:
            if f'SLT_WAVE_NIR' in header['ORIGFILE']:
                if 'T / Lamp activated.' not in str(header):
                    return True

    return False


def SPECTRAL_FORMAT_TAB_NIR(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the SPECTRAL_FORMAT_TAB_NIR tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'SPECTRAL_FORMAT_TAB_NIR' == header['HIERARCH ESO PRO CATG']:
            return True

    return False


def ARC_LINE_LIST_NIR(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the ARC_LINE_LIST_NIR tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'ARC_LINE_LIST_NIR' == header['HIERARCH ESO PRO CATG']:
            return True

    return False


def XSH_MOD_CFG_OPT_FMT_NIR(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the XSH_MOD_CFG_OPT_FMT_NIR tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'XSH_MOD_CFG_OPT_FMT_NIR' == header['HIERARCH ESO PRO CATG']:
            return True
    return False


def BP_MAP_RP_NIR(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the BP_MAP_RP_NIR tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'BP_MAP_RP_NIR' == header['HIERARCH ESO PRO CATG']:
            return True
    return False


def ORDER_TAB_EDGES_SLIT_NIR(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the ORDER_TAB_EDGES_SLIT_NIR tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'ORDER_TAB_EDGES_SLIT_NIR' == header['HIERARCH ESO PRO CATG']:
            return True
    return False


def DARK_NIR(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the DARK_NIR tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' not in header:
        if 'ORIGFILE' in header:
            if 'DARK_NIR' in header['ORIGFILE']:
                return True

    return False


def FLAT_SLIT_NIR_ON(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the FLAT_SLIT_NIR_ON tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''
    if 'HIERARCH ESO PRO CATG' not in header:
        if 'ORIGFILE' in header:
            if f'SLT_FLAT_NIR' in header['ORIGFILE']:
                if 'T / Lamp activated.' in str(header):
                    return True

    return False


def FLAT_SLIT_NIR_OFF(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the FLAT_SLIT_NIR_OFF tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''
    if 'HIERARCH ESO PRO CATG' not in header:
        if 'ORIGFILE' in header:
            if f'SLT_FLAT_NIR' in header['ORIGFILE']:
                if 'T / Lamp activated.' not in str(header):
                    return True

    return False


def ORDER_TAB_CENTR_NIR(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the ORDER_TAB_CENTR_NIR tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'ORDER_TAB_CENTR_NIR' == header['HIERARCH ESO PRO CATG']:
            return True

    return False


def ORDERDEF_NIR_ON(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the ORDERDEF_NIR_ON tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' not in header:
        if 'ORIGFILE' in header:
            if f'SLT_ODEF_NIR' in header['ORIGFILE']:
                if 'T / Lamp activated.' in str(header):
                    return True

    return False


def ORDERDEF_NIR_OFF(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the ORDERDEF_NIR_OFF tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' not in header:
        if 'ORIGFILE' in header:
            if f'SLT_ODEF_NIR' in header['ORIGFILE']:
                if 'T / Lamp activated.' not in str(header):
                    return True

    return False


def ORDER_TAB_GUESS_NIR(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the ORDER_TAB_GUESS_NIR tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'ORDER_TAB_GUESS_NIR' == header['HIERARCH ESO PRO CATG']:
            return True

    return False


def FMTCHK_NIR_ON(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the FMTCHK_NIR_ON tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' not in header:
        if 'ORIGFILE' in header:
            if 'SLT_FCK_NIR' in header['ORIGFILE']:
                if 'T / Lamp activated.' in str(header):
                    return True

    return False


def FMTCHK_NIR_OFF(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the FMTCHK_NIR_OFF tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' not in header:
        if 'ORIGFILE' in header:
            if 'SLT_FCK_NIR' in header['ORIGFILE']:
                if 'T / Lamp activated.' not in str(header):
                    return True

    return False


def XSH_MOD_CFG_TAB_NIR(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the XSH_MOD_CFG_TAB_NIR tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'XSH_MOD_CFG_TAB_NIR' == header['HIERARCH ESO PRO CATG']:
            return True
    return False


def XSH_MOD_CFG_OPT_2D_NIR(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the XSH_MOD_CFG_OPT_2D_NIR tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'XSH_MOD_CFG_OPT_2D_NIR' == header['HIERARCH ESO PRO CATG']:
            return True
    return False


def ARC_SLIT_NIR_ON(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the ARC_SLIT_NIR_ON tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' not in header:
        if 'ORIGFILE' in header:
            if 'SLT_ARC_NIR' in header['ORIGFILE']:
                if 'T / Lamp activated.' in str(header):
                    return True

    return False


def ARC_SLIT_NIR_OFF(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the ARC_SLIT_NIR_OFF tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' not in header:
        if 'ORIGFILE' in header:
            if 'SLT_ARC_NIR' in header['ORIGFILE']:
                if 'T / Lamp activated.' not in str(header):
                    return True

    return False


def STD_FLUX_SLIT_STARE_NIR(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the STD_FLUX_SLIT_STARE_NIR tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' not in header:
        if 'ORIGFILE' in header:
            if 'SLT_OBJ_NIR' in header['ORIGFILE']:
                if 'HIERARCH ESO DPR CATG' in header:
                    if 'CALIB' in header['HIERARCH ESO DPR CATG']:
                        return True

    return False


def MASTER_DARK_NIR(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the MASTER_DARK_NIR tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''
    if 'HIERARCH ESO PRO CATG' in header:
        if 'MASTER_DARK_NIR' == header['HIERARCH ESO PRO CATG']:
            return True

    return False


def MASTER_FLAT_SLIT_NIR(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the MASTER_DARK_NIR tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'MASTER_FLAT_SLIT_NIR' == header['HIERARCH ESO PRO CATG']:
            return True

    return False


def DISP_TAB_NIR(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the DISP_TAB_NIR tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'DISP_TAB_NIR' == header['HIERARCH ESO PRO CATG']:
            return True

    return False


def FLUX_STD_CATALOG_NIR(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the FLUX_STD_CATALOG_NIR tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'FLUX_STD_CATALOG_NIR' == header['HIERARCH ESO PRO CATG']:
            return True

    return False


def RESP_FIT_POINTS_CAT_NIR(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the RESP_FIT_POINTS_CAT_NIR tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'RESP_FIT_POINTS_CAT_NIR' == header['HIERARCH ESO PRO CATG']:
            return True

    return False


def ATMOS_EXT_NIR(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the ATMOS_EXT_NIR tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'ATMOS_EXT_NIR' == header['HIERARCH ESO PRO CATG']:
            return True

    return False


def SKY_LINE_LIST_NIR(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the SKY_LINE_LIST_NIR tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'SKY_LINE_LIST_NIR' == header['HIERARCH ESO PRO CATG']:
            return True

    return False


def OBJECT_SLIT_STARE_NIR(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the OBJECT_SLIT_STARE_NIR tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' not in header:
        if 'ORIGFILE' in header:
            if 'SLT_OBJ_NIR' in header['ORIGFILE']:
                if 'HIERARCH ESO DPR CATG' in header:
                    if 'SCIENCE' in header['HIERARCH ESO DPR CATG']:
                        return True

    return False


def SKY_MAP_NIR(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the SKY_MAP_NIR tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if 'HIERARCH ESO PRO CATG' in header:
        if 'SKY_MAP_NIR' == header['HIERARCH ESO PRO CATG']:
            return True

    return False


def GENERIC_TAG(header: astropy.io.fits.header, file_name: str = ''):
    '''
    This function checks wheter a given .fits file corresponds to the GENERIC_TAG tag.

    Input:
        header: 
            the header of the fits file
        file_name:
            the file name, in case the condition needs to open the file itself. 
            often not necessary, default ''

    Output:
        True or False          
    '''

    if False:
        return True

    return False
