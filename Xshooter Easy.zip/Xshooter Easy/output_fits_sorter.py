# THIS SCRIPT IS MEANT TO TAKE ALL THE OUTPUT FITS FILES AND PUT THEM IN THE FOLDER NAMED OUTPUT

import astropy.table
import astropy
import os

arms = ('NIR', 'VIS', 'UVB')

for arm in arms:
    name_0 = f'SDP_SCI_SLIT_MERGE1D_{arm}.fits'
    name_1 = f'SCI_SLIT_MERGE1D_{arm}.fits'
    name_2 = f'SCI_SLIT_MERGE2D_{arm}.fits'
    name_3 = f'SKY_SLIT_MERGE1D_{arm}.fits'
    name_4 = f'SKY_SLIT_MERGE2D_{arm}.fits'

    names = (name_0, name_1, name_2, name_3, name_4)

    for name in names:
        in_path = f'./{arm}/{name}'

        try:
            dat = astropy.io.fits.open(in_path)
            out_path = f'./Output/{name}'
            dat.writeto(out_path, overwrite=True)
        except:
            pass

print('Done!')