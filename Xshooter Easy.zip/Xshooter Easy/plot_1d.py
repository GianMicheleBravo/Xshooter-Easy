# THIS SCRIPT IS MEANT TO PLOT THE FULL 1D SPECTRUM

import astropy.table
import astropy
import matplotlib.pyplot as plt


arms = ('NIR', 'VIS', 'UVB')

for arm in arms:
        
    try:
        file_name = f'SDP_SCI_SLIT_MERGE1D_{arm}.fits' # TODO: set this
        path = f'./Output/{file_name}'
        dat = astropy.io.fits.open(path)
        dat = dat[1].data

        wavelength = dat['WAVE'][0]
        flux = dat['FLUX'][0]

        plt.plot(wavelength, flux, label = f'{arm} spectrum')
    except: 
        pass

plt.xlabel('Wavelength (nm)')
plt.ylabel('Flux (adu)')
plt.legend()
plt.grid()
plt.show()