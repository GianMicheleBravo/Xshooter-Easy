#!bin/bash

python3 input_fits_sorter.py

cd NIR/
bash xsh_all_recipes_NIR.sh
echo 'BASH SCRIPT: finished the NIR arm analysis.'
cd -

cd VIS/
bash xsh_all_recipes_VIS.sh
echo 'BASH SCRIPT: finished the VIS arm analysis.'
cd -

cd UVB/
bash xsh_all_recipes_UVB.sh
echo 'BASH SCRIPT: finished the UVB arm analysis.'
cd -

python3 output_fits_sorter.py

echo 'BASH SCRIPT: Done!'